﻿namespace OyunKutuphanesi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.labelYilan = new System.Windows.Forms.Label();
            this.labelAdamAsmaca = new System.Windows.Forms.Label();
            this.labelLabirent = new System.Windows.Forms.Label();
            this.labelEslestirme = new System.Windows.Forms.Label();
            this.labelZiplayanTop = new System.Windows.Forms.Label();
            this.btnYilan = new System.Windows.Forms.Button();
            this.btnAdamAsmaca = new System.Windows.Forms.Button();
            this.btnLabirent = new System.Windows.Forms.Button();
            this.btnEslestirme = new System.Windows.Forms.Button();
            this.btnZiplayanTop = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, 24);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(262, 24);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 81);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(30, 138);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 81);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(262, 138);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 81);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(30, 252);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(75, 81);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 12;
            this.pictureBox5.TabStop = false;
            // 
            // labelYilan
            // 
            this.labelYilan.AutoSize = true;
            this.labelYilan.Location = new System.Drawing.Point(112, 49);
            this.labelYilan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelYilan.Name = "labelYilan";
            this.labelYilan.Size = new System.Drawing.Size(64, 13);
            this.labelYilan.TabIndex = 1;
            this.labelYilan.Text = "Yılan Oyunu";
            // 
            // labelAdamAsmaca
            // 
            this.labelAdamAsmaca.AutoSize = true;
            this.labelAdamAsmaca.Location = new System.Drawing.Point(345, 49);
            this.labelAdamAsmaca.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAdamAsmaca.Name = "labelAdamAsmaca";
            this.labelAdamAsmaca.Size = new System.Drawing.Size(75, 13);
            this.labelAdamAsmaca.TabIndex = 4;
            this.labelAdamAsmaca.Text = "Adam Asmaca";
            // 
            // labelLabirent
            // 
            this.labelLabirent.AutoSize = true;
            this.labelLabirent.Location = new System.Drawing.Point(112, 162);
            this.labelLabirent.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLabirent.Name = "labelLabirent";
            this.labelLabirent.Size = new System.Drawing.Size(79, 13);
            this.labelLabirent.TabIndex = 7;
            this.labelLabirent.Text = "Labirent Oyunu";
            // 
            // labelEslestirme
            // 
            this.labelEslestirme.AutoSize = true;
            this.labelEslestirme.Location = new System.Drawing.Point(345, 162);
            this.labelEslestirme.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelEslestirme.Name = "labelEslestirme";
            this.labelEslestirme.Size = new System.Drawing.Size(88, 13);
            this.labelEslestirme.TabIndex = 10;
            this.labelEslestirme.Text = "Eşleştirme Oyunu";
            // 
            // labelZiplayanTop
            // 
            this.labelZiplayanTop.AutoSize = true;
            this.labelZiplayanTop.Location = new System.Drawing.Point(112, 276);
            this.labelZiplayanTop.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelZiplayanTop.Name = "labelZiplayanTop";
            this.labelZiplayanTop.Size = new System.Drawing.Size(103, 13);
            this.labelZiplayanTop.TabIndex = 13;
            this.labelZiplayanTop.Text = "Zıplayan Top Oyunu";
            // 
            // btnYilan
            // 
            this.btnYilan.Location = new System.Drawing.Point(112, 73);
            this.btnYilan.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnYilan.Name = "btnYilan";
            this.btnYilan.Size = new System.Drawing.Size(56, 20);
            this.btnYilan.TabIndex = 2;
            this.btnYilan.Text = "Oyna";
            this.btnYilan.UseVisualStyleBackColor = true;
            // 
            // btnAdamAsmaca
            // 
            this.btnAdamAsmaca.Location = new System.Drawing.Point(345, 73);
            this.btnAdamAsmaca.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAdamAsmaca.Name = "btnAdamAsmaca";
            this.btnAdamAsmaca.Size = new System.Drawing.Size(56, 20);
            this.btnAdamAsmaca.TabIndex = 5;
            this.btnAdamAsmaca.Text = "Oyna";
            this.btnAdamAsmaca.UseVisualStyleBackColor = true;
            // 
            // btnLabirent
            // 
            this.btnLabirent.Location = new System.Drawing.Point(112, 187);
            this.btnLabirent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnLabirent.Name = "btnLabirent";
            this.btnLabirent.Size = new System.Drawing.Size(56, 20);
            this.btnLabirent.TabIndex = 8;
            this.btnLabirent.Text = "Oyna";
            this.btnLabirent.UseVisualStyleBackColor = true;
            // 
            // btnEslestirme
            // 
            this.btnEslestirme.Location = new System.Drawing.Point(345, 187);
            this.btnEslestirme.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnEslestirme.Name = "btnEslestirme";
            this.btnEslestirme.Size = new System.Drawing.Size(56, 20);
            this.btnEslestirme.TabIndex = 11;
            this.btnEslestirme.Text = "Oyna";
            this.btnEslestirme.UseVisualStyleBackColor = true;
            // 
            // btnZiplayanTop
            // 
            this.btnZiplayanTop.Location = new System.Drawing.Point(112, 301);
            this.btnZiplayanTop.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnZiplayanTop.Name = "btnZiplayanTop";
            this.btnZiplayanTop.Size = new System.Drawing.Size(56, 20);
            this.btnZiplayanTop.TabIndex = 14;
            this.btnZiplayanTop.Text = "Oyna";
            this.btnZiplayanTop.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 463);
            this.Controls.Add(this.btnZiplayanTop);
            this.Controls.Add(this.labelZiplayanTop);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.btnEslestirme);
            this.Controls.Add(this.labelEslestirme);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.btnLabirent);
            this.Controls.Add(this.labelLabirent);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnAdamAsmaca);
            this.Controls.Add(this.labelAdamAsmaca);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnYilan);
            this.Controls.Add(this.labelYilan);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AnaSayfaForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label labelYilan;
        private System.Windows.Forms.Label labelAdamAsmaca;
        private System.Windows.Forms.Label labelLabirent;
        private System.Windows.Forms.Label labelEslestirme;
        private System.Windows.Forms.Label labelZiplayanTop;
        private System.Windows.Forms.Button btnYilan;
        private System.Windows.Forms.Button btnAdamAsmaca;
        private System.Windows.Forms.Button btnLabirent;
        private System.Windows.Forms.Button btnEslestirme;
        private System.Windows.Forms.Button btnZiplayanTop;
    }
}

