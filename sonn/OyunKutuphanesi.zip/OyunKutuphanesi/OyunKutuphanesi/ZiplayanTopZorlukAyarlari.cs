namespace OyunKutuphanesi
{
    public class ZiplayanTopZorlukAyarlari
    {
        public int PlatformGenislik { get; private set; }
        public int TopHizi { get; private set; }
        public int EngelSayisi { get; private set; }
        public float SkorCarpani { get; private set; }

        private ZiplayanTopZorlukAyarlari(int platformGenislik, int topHizi, int engelSayisi, float skorCarpani)
        {
            PlatformGenislik = platformGenislik;
            TopHizi = topHizi;
            EngelSayisi = engelSayisi;
            SkorCarpani = skorCarpani;
        }

        public static ZiplayanTopZorlukAyarlari Kolay()
        {
            return new ZiplayanTopZorlukAyarlari(
                platformGenislik: 150,
                topHizi: 3,
                engelSayisi: 3,
                skorCarpani: 1.0f
            );
        }

        public static ZiplayanTopZorlukAyarlari Orta()
        {
            return new ZiplayanTopZorlukAyarlari(
                platformGenislik: 100,
                topHizi: 4,
                engelSayisi: 5,
                skorCarpani: 1.5f
            );
        }

        public static ZiplayanTopZorlukAyarlari Zor()
        {
            return new ZiplayanTopZorlukAyarlari(
                platformGenislik: 80,
                topHizi: 5,
                engelSayisi: 7,
                skorCarpani: 2.0f
            );
        }
    }
} 