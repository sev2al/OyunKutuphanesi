using System.Drawing;

namespace OyunKutuphanesi
{
    public abstract class Engel
    {
        public int X { get; protected set; }
        public int Y { get; protected set; }
        public int Genislik { get; protected set; }
        public int Yukseklik { get; protected set; }
        public Color Renk { get; protected set; }

        public Rectangle Alan => new Rectangle(X, Y, Genislik, Yukseklik);

        protected Engel(int x, int y, int genislik, int yukseklik, Color renk)
        {
            X = x;
            Y = y;
            Genislik = genislik;
            Yukseklik = yukseklik;
            Renk = renk;
        }

        public abstract void TopaCarpmaEtkisi(Top top);

        public virtual void Ciz(Graphics g)
        {
            using (SolidBrush firca = new SolidBrush(Renk))
            {
                g.FillRectangle(firca, X, Y, Genislik, Yukseklik);
            }
        }
    }

    public class SertEngel : Engel
    {
        public SertEngel(int x, int y, int genislik, int yukseklik) 
            : base(x, y, genislik, yukseklik, Color.DarkRed)
        {
        }

        public override void TopaCarpmaEtkisi(Top top)
        {
            // Top sert engele çarptığında yön değiştirir
            top.EngeleCarp(-top.HizX, -top.HizY);
        }
    }

    public class HizlandiranEngel : Engel
    {
        private const float HizArtisKatsayisi = 1.5f;

        public HizlandiranEngel(int x, int y, int genislik, int yukseklik) 
            : base(x, y, genislik, yukseklik, Color.Green)
        {
        }

        public override void TopaCarpmaEtkisi(Top top)
        {
            // Top hızlandıran engele çarptığında hızı artar
            top.EngeleCarp(top.HizX * HizArtisKatsayisi, -top.HizY * HizArtisKatsayisi);
        }
    }

    public class YavaslataEngel : Engel
    {
        private const float HizAzalisKatsayisi = 0.7f;

        public YavaslataEngel(int x, int y, int genislik, int yukseklik) 
            : base(x, y, genislik, yukseklik, Color.Yellow)
        {
        }

        public override void TopaCarpmaEtkisi(Top top)
        {
            // Top yavaşlatan engele çarptığında hızı azalır
            top.EngeleCarp(top.HizX * HizAzalisKatsayisi, -top.HizY * HizAzalisKatsayisi);
        }
    }
} 