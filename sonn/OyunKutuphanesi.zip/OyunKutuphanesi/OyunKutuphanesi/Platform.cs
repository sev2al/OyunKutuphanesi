using System;
using System.Drawing;
using System.Windows.Forms;

namespace OyunKutuphanesi
{
    public class Platform
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public int Genislik { get; private set; }
        public int Yukseklik { get; private set; }
        public int HareketHizi { get; private set; }

        public Rectangle Alan => new Rectangle(X, Y, Genislik, Yukseklik);

        public Platform(int x, int y, int genislik, int yukseklik, int hareketHizi)
        {
            X = x;
            Y = y;
            Genislik = genislik;
            Yukseklik = yukseklik;
            HareketHizi = hareketHizi;
        }

        public void HareketEt(Keys tus, Rectangle oyunAlani)
        {
            int yeniX = X;

            if (tus == Keys.Left)
            {
                yeniX = Math.Max(oyunAlani.Left, X - HareketHizi);
            }
            else if (tus == Keys.Right)
            {
                yeniX = Math.Min(oyunAlani.Right - Genislik, X + HareketHizi);
            }

            X = yeniX;
        }

        public void Ciz(Graphics g)
        {
            g.FillRectangle(Brushes.Blue, X, Y, Genislik, Yukseklik);
        }
    }
} 