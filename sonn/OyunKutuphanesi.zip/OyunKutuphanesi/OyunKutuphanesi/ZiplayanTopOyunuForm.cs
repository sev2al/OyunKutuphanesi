using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace OyunKutuphanesi
{
    public partial class ZiplayanTopOyunuForm : Form
    {
        private Top top;
        private Platform platform;
        private List<Engel> engeller;
        private Timer oyunTimer;
        private ZiplayanTopZorlukAyarlari zorlukAyarlari;
        
        private int skor;
        private bool oyunDevamEdiyor;
        private Random random;

        // UI Kontrolleri
        private Panel oyunAlani;
        private ComboBox zorlukSecici;
        private Button baslatButton;
        private Label skorLabel;

        public ZiplayanTopOyunuForm()
        {
            InitializeComponent();
            KontrolleriOlustur();
            OyunuHazirla();
        }

        private void KontrolleriOlustur()
        {
            // Form özellikleri
            this.Text = "Zıplayan Top Oyunu";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Üst panel
            Panel ustPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Color.LightGray
            };

            // Zorluk seçici
            zorlukSecici = new ComboBox
            {
                Location = new Point(10, 15),
                Size = new Size(120, 25),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            zorlukSecici.Items.AddRange(new string[] { "Kolay", "Orta", "Zor" });
            zorlukSecici.SelectedIndex = 0;

            // Başlat butonu
            baslatButton = new Button
            {
                Location = new Point(140, 15),
                Size = new Size(100, 25),
                Text = "Başlat"
            };
            baslatButton.Click += BaslatButton_Click;

            // Skor etiketi
            skorLabel = new Label
            {
                Location = new Point(250, 15),
                Size = new Size(150, 25),
                Text = "Skor: 0",
                TextAlign = ContentAlignment.MiddleLeft
            };

            // Oyun alanı
            oyunAlani = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };
            oyunAlani.Paint += OyunAlani_Paint;

            // Timer
            oyunTimer = new Timer
            {
                Interval = 16 // ~60 FPS
            };
            oyunTimer.Tick += OyunTimer_Tick;

            // Kontrolleri forma ekle
            ustPanel.Controls.AddRange(new Control[] { zorlukSecici, baslatButton, skorLabel });
            this.Controls.AddRange(new Control[] { ustPanel, oyunAlani });

            // Klavye olayları
            this.KeyPreview = true;
            this.KeyDown += ZiplayanTopOyunuForm_KeyDown;
        }

        private void OyunuHazirla()
        {
            random = new Random();
            oyunDevamEdiyor = false;
            skor = 0;
            engeller = new List<Engel>();

            // Zorluk ayarlarını yükle
            ZorlukAyarlariniYukle();

            // Oyun nesnelerini oluştur
            OyunNesneleriniOlustur();
        }

        private void ZorlukAyarlariniYukle()
        {
            switch (zorlukSecici.SelectedIndex)
            {
                case 0:
                    zorlukAyarlari = ZiplayanTopZorlukAyarlari.Kolay();
                    break;
                case 1:
                    zorlukAyarlari = ZiplayanTopZorlukAyarlari.Orta();
                    break;
                case 2:
                    zorlukAyarlari = ZiplayanTopZorlukAyarlari.Zor();
                    break;
                default:
                    zorlukAyarlari = ZiplayanTopZorlukAyarlari.Kolay();
                    break;
            }
        }

        private void OyunNesneleriniOlustur()
        {
            // Platform oluştur
            platform = new Platform(
                oyunAlani.Width / 2 - zorlukAyarlari.PlatformGenislik / 2,
                oyunAlani.Height - 30,
                zorlukAyarlari.PlatformGenislik,
                10,
                8
            );

            // Top oluştur
            top = new Top(
                oyunAlani.Width / 2,
                oyunAlani.Height / 2,
                10
            );

            // Engelleri oluştur
            EngelleriOlustur();
        }

        private void EngelleriOlustur()
        {
            engeller.Clear();
            int engelGenislik = 60;
            int engelYukseklik = 20;

            for (int i = 0; i < zorlukAyarlari.EngelSayisi; i++)
            {
                int x = random.Next(0, oyunAlani.Width - engelGenislik);
                int y = random.Next(50, oyunAlani.Height / 2);
                int engelTipi = random.Next(3);
                Engel yeniEngel;

                switch (engelTipi)
                {
                    case 0:
                        yeniEngel = new SertEngel(x, y, engelGenislik, engelYukseklik);
                        break;
                    case 1:
                        yeniEngel = new HizlandiranEngel(x, y, engelGenislik, engelYukseklik);
                        break;
                    default:
                        yeniEngel = new YavaslataEngel(x, y, engelGenislik, engelYukseklik);
                        break;
                }

                engeller.Add(yeniEngel);
            }
        }

        private void BaslatButton_Click(object sender, EventArgs e)
        {
            if (!oyunDevamEdiyor)
            {
                OyunuBaslat();
            }
            else
            {
                OyunuBitir();
            }
        }

        private void OyunuBaslat()
        {
            OyunuHazirla();
            oyunDevamEdiyor = true;
            oyunTimer.Start();
            baslatButton.Text = "Bitir";
            zorlukSecici.Enabled = false;
        }

        private void OyunuBitir()
        {
            oyunDevamEdiyor = false;
            oyunTimer.Stop();
            baslatButton.Text = "Başlat";
            zorlukSecici.Enabled = true;
            MessageBox.Show($"Oyun bitti!\nSkorunuz: {skor}", "Oyun Sonu", 
                          MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OyunTimer_Tick(object sender, EventArgs e)
        {
            if (!oyunDevamEdiyor) return;

            // Top hareketini güncelle
            top.Hareket(oyunAlani.ClientRectangle);

            // Platform ile çarpışma kontrolü
            if (top.CarpismaKontrol(platform.Alan))
            {
                top.PlatformaCarp();
                skor += 10;
                skorLabel.Text = $"Skor: {skor}";
            }

            // Engellerle çarpışma kontrolü
            foreach (var engel in engeller)
            {
                if (top.CarpismaKontrol(engel.Alan))
                {
                    engel.TopaCarpmaEtkisi(top);
                    skor += 5;
                    skorLabel.Text = $"Skor: {skor}";
                }
            }

            // Top aktif değilse oyunu bitir
            if (!top.AktifMi)
            {
                OyunuBitir();
            }

            // Ekranı yenile
            oyunAlani.Invalidate();
        }

        private void OyunAlani_Paint(object sender, PaintEventArgs e)
        {
            // Arka planı temizle
            e.Graphics.Clear(Color.White);

            // Oyun nesnelerini çiz
            if (platform != null) platform.Ciz(e.Graphics);
            if (top != null) top.Ciz(e.Graphics);
            foreach (var engel in engeller)
            {
                engel.Ciz(e.Graphics);
            }
        }

        private void ZiplayanTopOyunuForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (!oyunDevamEdiyor) return;

            platform.HareketEt(e.KeyCode, oyunAlani.ClientRectangle);
            oyunAlani.Invalidate();
        }
    }
} 