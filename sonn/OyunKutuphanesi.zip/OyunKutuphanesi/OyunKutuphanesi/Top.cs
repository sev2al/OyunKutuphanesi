using System;
using System.Drawing;

namespace OyunKutuphanesi
{
    public class Top
    {
        public float X { get; private set; }
        public float Y { get; private set; }
        public float HizX { get; private set; }
        public float HizY { get; private set; }
        public int Yaricap { get; private set; }
        public bool AktifMi { get; private set; }

        private readonly float YercekimiIvmesi = 0.5f;
        private readonly float ZiplamaKatsayisi = -0.7f;

        public Top(int x, int y, int yaricap)
        {
            X = x;
            Y = y;
            Yaricap = yaricap;
            HizX = 3.0f;
            HizY = 0;
            AktifMi = true;
        }

        public void Hareket(Rectangle oyunAlani)
        {
            // Yatay hareket
            X += HizX;

            // Dikey hareket (yerçekimi etkisi)
            HizY += YercekimiIvmesi;
            Y += HizY;

            // Yan duvarlarla çarpışma kontrolü
            if (X - Yaricap <= oyunAlani.Left || X + Yaricap >= oyunAlani.Right)
            {
                HizX = -HizX;
                X = Math.Max(oyunAlani.Left + Yaricap, Math.Min(X, oyunAlani.Right - Yaricap));
            }

            // Alt sınır kontrolü (oyun sonu)
            if (Y + Yaricap > oyunAlani.Bottom)
            {
                AktifMi = false;
            }

            // Üst sınır kontrolü
            if (Y - Yaricap < oyunAlani.Top)
            {
                Y = oyunAlani.Top + Yaricap;
                HizY = -HizY * ZiplamaKatsayisi;
            }
        }

        public void PlatformaCarp()
        {
            HizY = HizY * ZiplamaKatsayisi;
        }

        public void EngeleCarp(float yeniHizX, float yeniHizY)
        {
            HizX = yeniHizX;
            HizY = yeniHizY;
        }

        public bool CarpismaKontrol(Rectangle nesne)
        {
            // Topun merkezi ile dikdörtgen nesne arasındaki çarpışma kontrolü
            float enYakinX = Math.Max(nesne.Left, Math.Min(X, nesne.Right));
            float enYakinY = Math.Max(nesne.Top, Math.Min(Y, nesne.Bottom));

            float uzaklikX = X - enYakinX;
            float uzaklikY = Y - enYakinY;

            return (uzaklikX * uzaklikX + uzaklikY * uzaklikY) < (Yaricap * Yaricap);
        }

        public void Ciz(Graphics g)
        {
            g.FillEllipse(Brushes.Red, X - Yaricap, Y - Yaricap, Yaricap * 2, Yaricap * 2);
        }
    }
} 