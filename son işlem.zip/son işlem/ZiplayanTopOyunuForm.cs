using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;

namespace OyunKutuphanesi
{
    public partial class ZiplayanTopOyunuForm : Form
    {
        private Top top;
        private Platform platform;
        private List<Engel> engeller;
        private Timer oyunTimer;
        private ZiplayanTopZorlukAyarlari zorlukAyarlari;
        
        private int skor;
        private bool oyunDevamEdiyor;
        private Random random;
        private bool solTusBasili;
        private bool sagTusBasili;

        // UI Kontrolleri
        private Panel oyunAlani;
        private ComboBox zorlukSecici;
        private Button baslatButton;
        private Label skorLabel;

        public ZiplayanTopOyunuForm()
        {
            InitializeComponent();
            KontrolleriOlustur();
            OyunuHazirla();
            this.KeyPreview = true;  // Form seviyesinde tuş olaylarını yakala
            this.KeyDown += ZiplayanTopOyunuForm_KeyDown;
            this.KeyUp += ZiplayanTopOyunuForm_KeyUp;
        }

        private void KontrolleriOlustur()
        {
            // Form özellikleri
            this.Text = "Zıplayan Top Oyunu";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Üst panel
            Panel ustPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = Color.LightGray
            };

            // Zorluk seçici
            zorlukSecici = new ComboBox
            {
                Location = new Point(10, 15),
                Size = new Size(120, 25),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            zorlukSecici.Items.AddRange(new string[] { "Kolay", "Orta", "Zor" });
            zorlukSecici.SelectedIndex = 0;

            // Başlat butonu
            baslatButton = new Button
            {
                Location = new Point(140, 15),
                Size = new Size(100, 25),
                Text = "Başlat"
            };
            baslatButton.Click += BaslatButton_Click;

            // Skor etiketi
            skorLabel = new Label
            {
                Location = new Point(250, 15),
                Size = new Size(150, 25),
                Text = "Skor: 0",
                TextAlign = ContentAlignment.MiddleLeft
            };

            // Oyun alanı
            oyunAlani = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };
            oyunAlani.Paint += OyunAlani_Paint;

            // Timer
            oyunTimer = new Timer
            {
                Interval = 16 // ~60 FPS
            };
            oyunTimer.Tick += OyunTimer_Tick;

            // Kontrolleri forma ekle
            ustPanel.Controls.AddRange(new Control[] { zorlukSecici, baslatButton, skorLabel });
            this.Controls.AddRange(new Control[] { ustPanel, oyunAlani });
        }

        private void OyunuHazirla()
        {
            // Oyun nesnelerini oluştur
            int platformGenislik = 100;
            int platformYukseklik = 20;
            int platformHiz = 5;
            platform = new Platform(
                (oyunAlani.Width - platformGenislik) / 2,
                oyunAlani.Height - platformYukseklik - 10,
                platformGenislik,
                platformYukseklik,
                platformHiz
            );
            
            top = new Top(oyunAlani.Width / 2, oyunAlani.Height / 2);
            engeller = new List<Engel>();
            random = new Random();
            
            // Oyun durumunu sıfırla
            oyunDevamEdiyor = false;
            skor = 0;
            skorLabel.Text = "Skor: 0";
            solTusBasili = false;
            sagTusBasili = false;
            
            // Zorluk ayarlarını uygula
            zorlukAyarlari = new ZiplayanTopZorlukAyarlari();
            UygulaZorlukAyarlari();
            
            // Engelleri oluştur
            OlusturEngeller();
        }

        private void OlusturEngeller()
        {
            engeller.Clear();
            int engelGenislik = 60;
            int engelYukseklik = 20;
            int yatayBosluk = oyunAlani.Width / (zorlukAyarlari.EngelSayisi + 1);
            
            for (int i = 0; i < zorlukAyarlari.EngelSayisi; i++)
            {
                int engelX = (i + 1) * yatayBosluk - engelGenislik / 2;
                int engelY = oyunAlani.Height / 4;
                
                // Rastgele engel türü seç
                int engelTuru = random.Next(3);
                Engel yeniEngel;
                
                switch (engelTuru)
                {
                    case 0:
                        yeniEngel = new SertEngel(engelX, engelY, engelGenislik, engelYukseklik);
                        break;
                    case 1:
                        yeniEngel = new HizlandiranEngel(engelX, engelY, engelGenislik, engelYukseklik);
                        break;
                    default:
                        yeniEngel = new YavaslataEngel(engelX, engelY, engelGenislik, engelYukseklik);
                        break;
                }
                
                engeller.Add(yeniEngel);
            }
        }

        private void UygulaZorlukAyarlari()
        {
            switch (zorlukSecici.SelectedIndex)
            {
                case 0: // Kolay
                    zorlukAyarlari.PlatformHizi = 5;
                    zorlukAyarlari.TopHizi = 4;
                    zorlukAyarlari.EngelSayisi = 3;
                    break;
                case 1: // Orta
                    zorlukAyarlari.PlatformHizi = 7;
                    zorlukAyarlari.TopHizi = 6;
                    zorlukAyarlari.EngelSayisi = 5;
                    break;
                case 2: // Zor
                    zorlukAyarlari.PlatformHizi = 9;
                    zorlukAyarlari.TopHizi = 8;
                    zorlukAyarlari.EngelSayisi = 7;
                    break;
            }
        }

        private void BaslatButton_Click(object sender, EventArgs e)
        {
            if (!oyunDevamEdiyor)
            {
                OyunuBaslat();
            }
            else
            {
                OyunuDurdur();
            }
        }

        private void OyunuBaslat()
        {
            // Oyunu sıfırla ve yeniden hazırla
            OyunuHazirla();
            
            // Oyunu başlat
            oyunDevamEdiyor = true;
            baslatButton.Text = "Durdur";
            oyunTimer.Start();
        }

        private void OyunuDurdur()
        {
            oyunDevamEdiyor = false;
            baslatButton.Text = "Başlat";
            oyunTimer.Stop();
        }

        private void ZiplayanTopOyunuForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (!oyunDevamEdiyor) return;

            switch (e.KeyCode)
            {
                case Keys.Left:
                    solTusBasili = true;
                    break;
                case Keys.Right:
                    sagTusBasili = true;
                    break;
            }
        }

        private void ZiplayanTopOyunuForm_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    solTusBasili = false;
                    break;
                case Keys.Right:
                    sagTusBasili = false;
                    break;
            }
        }

        private void OyunTimer_Tick(object sender, EventArgs e)
        {
            if (!oyunDevamEdiyor) return;

            // Platform hareketini güncelle
            if (solTusBasili)
            {
                platform.SolaHareket(zorlukAyarlari.PlatformHizi, 0, oyunAlani.Width);
            }
            if (sagTusBasili)
            {
                platform.SagaHareket(zorlukAyarlari.PlatformHizi, 0, oyunAlani.Width);
            }

            // Top hareketini güncelle
            top.Hareket();
            
            // Sınır kontrolü
            top.SinirKontrol(oyunAlani.ClientRectangle);

            // Platform ile çarpışma kontrolü
            if (top.CarpismaKontrol(platform))
            {
                skor += 10;
                skorLabel.Text = $"Skor: {skor}";
            }

            // Engellerle çarpışma kontrolü
            foreach (var engel in engeller)
            {
                if (top.CarpismaKontrol(engel.Alan))
                {
                    engel.TopaCarpmaEtkisi(top);
                    skor += 20;
                    skorLabel.Text = $"Skor: {skor}";
                }
            }

            // Alt sınır kontrolü (oyun kaybetme)
            if (top.Y >= oyunAlani.Height)
            {
                OyunBitti();
            }

            // Ekranı yenile
            oyunAlani.Invalidate();
        }

        private void OyunBitti()
        {
            oyunDevamEdiyor = false;
            oyunTimer.Stop();
            MessageBox.Show($"Oyun Bitti!\nSkorunuz: {skor}", "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Information);
            baslatButton.Text = "Başlat";
        }

        private void OyunAlani_Paint(object sender, PaintEventArgs e)
        {
            if (platform != null && top != null)
            {
                // Platform çiz
                platform.Ciz(e.Graphics);
                
                // Top çiz
                top.Ciz(e.Graphics);
                
                // Engelleri çiz
                foreach (Engel engel in engeller)
                {
                    engel.Ciz(e.Graphics);
                }
            }
        }
    }
} 